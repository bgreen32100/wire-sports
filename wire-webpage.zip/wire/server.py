#!/usr/bin/env python3
import json, os, re, time, urllib.parse, urllib.request, xml.etree.ElementTree as ET
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from email.utils import parsedate_to_datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PORT=int(os.environ.get('PORT','8000'))
CACHE={'at':0,'items':[]}
TTL=300
ESPN={
 'NFL':'https://www.espn.com/espn/rss/nfl/news',
 'NBA':'https://www.espn.com/espn/rss/nba/news',
}
# High-signal names from the user's roster. Google News RSS provides public, linked reporting
# that mentions/attributes these sources; ESPN RSS supplies direct ESPN headlines.
WATCH=['Adam Schefter','Ian Rapoport','Ian Begley','Tommy Beer','Jonathan Givony','Jake Fischer','Marc Stein','Chris Haynes','Zack Rosenblatt','Rich Cimini','Brian Costello','Fred Katz','Bobby Marks','Mike Garafolo','Jeremy Fowler','Field Yates','Jordan Schultz','Daniel Jeremiah','Dane Brugler','Benjamin Solak']

def txt(node, tag):
    x=node.find(tag); return (x.text or '').strip() if x is not None and x.text else ''

def epoch(s):
    try:return int(parsedate_to_datetime(s).timestamp())
    except:return int(time.time())

def clean_title(s):
    return re.sub(r'\s+-\s+[^-]{2,60}$','',s).strip()

def cats(title, desc=''):
    s=(title+' '+desc).lower(); out=[]
    if any(k in s for k in ['nfl','jets','football','quarterback','touchdown','super bowl']):out.append('NFL')
    if any(k in s for k in ['nba','knicks','basketball','draft','all-star']):out.append('NBA')
    if any(k in s for k in ['jets','garrett wilson','breece hall']):out.append('JETS')
    if any(k in s for k in ['knicks','jalen brunson','karl-anthony towns','josh hart']):out.append('KNICKS')
    if any(k in s for k in ['fantasy','injury','inactive','depth chart']):out.append('FANTASY')
    return out or ['SPORTS']

def fetch_rss(url, source_hint=None, limit=20):
    req=urllib.request.Request(url,headers={'User-Agent':'WIRE/1.0 (+personal sports reader)'})
    with urllib.request.urlopen(req,timeout=10) as r:data=r.read()
    root=ET.fromstring(data); items=[]
    for it in root.findall('.//item')[:limit]:
        title=txt(it,'title'); link=txt(it,'link'); desc=re.sub('<[^>]+>',' ',txt(it,'description'))
        pub=txt(it,'pubDate'); source=source_hint or txt(it,'source') or 'News'
        if not title or not link:continue
        items.append({'id':link,'title':clean_title(title),'summary':re.sub(r'\s+',' ',desc).strip()[:260],
          'url':link,'source':source,'published':epoch(pub),'categories':cats(title,desc)})
    return items

def gnews(name):
    q=urllib.parse.quote('"'+name+'" sports when:2d')
    url='https://news.google.com/rss/search?q='+q+'&hl=en-US&gl=US&ceid=US:en'
    return fetch_rss(url,name,5)

def live_items():
    if CACHE['items'] and time.time()-CACHE['at']<TTL:return CACHE['items']
    items=[]
    for league,url in ESPN.items():
        try:items += fetch_rss(url,'ESPN',25)
        except Exception:pass
    for name in WATCH:
        try:items += gnews(name)
        except Exception:pass
    # Deduplicate exact URLs/titles, newest first.
    seen=set(); out=[]
    for x in sorted(items,key=lambda z:z['published'],reverse=True):
        key=re.sub(r'\W+',' ',x['title'].lower()).strip()
        if x['url'] in seen or key in seen:continue
        seen.add(x['url']);seen.add(key);out.append(x)
    CACHE.update(at=time.time(),items=out[:120])
    return CACHE['items']

class Handler(SimpleHTTPRequestHandler):
    def translate_path(self,path):
        rel=urllib.parse.urlparse(path).path.lstrip('/') or 'index.html'
        return str(ROOT/rel)
    def do_GET(self):
        if urllib.parse.urlparse(self.path).path=='/api/feed':
            try:
                body=json.dumps({'updated':int(time.time()),'items':live_items()}).encode()
                self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
            except Exception as e:
                body=json.dumps({'error':str(e),'items':[]}).encode();self.send_response(502);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(body)
            return
        return super().do_GET()

if __name__=='__main__':
    os.chdir(ROOT)
    print(f'WIRE running at http://localhost:{PORT}')
    ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()
