WIRE — live hybrid sports reader

Run locally:
  python3 server.py
Then open:
  http://localhost:8000

What is live now:
- ESPN NFL + NBA RSS headlines
- Public Google News RSS results that mention/attribute a high-signal subset of your 87-source roster
- Automatic NFL / NBA / Jets / Knicks / Fantasy tagging
- Refresh every 5 minutes
- Source links open the original reporting destination
- Existing filters, saved stories, source controls and Catch Up UI remain

No X API key is required for this version.

Deployment:
This folder can run on any host that supports a long-running Python process. Set PORT if the host provides one.
